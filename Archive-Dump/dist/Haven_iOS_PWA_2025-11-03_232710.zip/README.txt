Haven Galaxy iOS PWA
===================

Files:
- Haven_Galaxy_iOS.html - The complete app (open in Safari on iOS)
- iOS_INSTALLATION_GUIDE.txt - Step-by-step installation instructions

Quick Start:
1. Email Haven_Galaxy_iOS.html to your iOS device
2. Open it in Safari
3. Tap Share → Add to Home Screen
4. Launch from home screen!

The app includes a 3D galaxy map viewer and full data entry form.
All data is stored locally on your device.
