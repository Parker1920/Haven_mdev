Haven Control Room (Windows)

Run: Double-click HavenControlRoom.exe
Notes: Windows may show a SmartScreen prompt. Click 'More info' > 'Run anyway'.
